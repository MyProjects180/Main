# This is a demo of running face recognition on a Raspberry Pi.
# This program will print out the names of anyone it recognizes to the console.

# To run this, you need a Raspberry Pi 2 (or greater) with face_recognition and
# the picamera[array] module installed.
# You can follow this installation instructions to get your RPi set up:
# https://gist.github.com/ageitgey/1ac8dbe8572f3f533df6269dab35df65

import face_recognition
import picamera
import numpy as np
from xlwt import Workbook
import dropbox

z1=0
z2=0
z3=0
z4=0
z5=0

y1=0
y2=0
y3=0
y4=0
y5=0

book = Workbook()
sheet_one=book.add_sheet('Sample_one.xls')
sheet_one.write(0,0,'STUDENTS PRESENT')
sheet_one.col(0).width = 8000

def main_p1(): 
    sheet_one.write(1,0,'p1')
    book.save('Attendance.xls') 
def main_p2(): 
    sheet_one.write(2,0,'p2')
    book.save('Attendance.xls') 
def main_p3(): 
    sheet_one.write(3,0,'p3')
    book.save('Attendance.xls') 	
def main_p4(): 
    sheet_one.write(4,0,'p4')
    book.save('Attendance.xls') 
def main_p5(): 
    sheet_one.write(5,0,'p5')
    book.save('Attendance.xls') 		
	

camera = picamera.PiCamera()
camera.resolution = (320, 240)
output = np.empty((240, 320, 3), dtype=np.uint8)


print("Loading known face image(s)")

p1_image = face_recognition.load_image_file("p1.jpg")
print("p1 image load")
p1_face_encoding = face_recognition.face_encodings(p1_image)[0]
print("p1 image encode")

p2_image = face_recognition.load_image_file("p2.jpg")
print("p2 image load")
p2_face_encoding = face_recognition.face_encodings(p2_image)[0]
print("p2 image encode")

p3_image = face_recognition.load_image_file("p3.jpg")
print("p3 image load")
p3_face_encoding = face_recognition.face_encodings(p3_image)[0]
print("p3 image encode")

p4_image = face_recognition.load_image_file("p4.jpg")
print("p4 image load")
p4_face_encoding = face_recognition.face_encodings(p4_image)[0]
print("p4 image encode")

p5_image = face_recognition.load_image_file("p5.jpg")
print("p5 image load")
p5_face_encoding = face_recognition.face_encodings(p5_image)[0]
print("p5 image encode")

# Initialize some variables
face_locations = []
face_encodings = []

while True:
    print("Capturing image.")
    # Grab a single frame of video from the RPi camera as a numpy array
    camera.capture(output, format="rgb")

    # Find all the faces and face encodings in the current frame of video
    face_locations = face_recognition.face_locations(output)
    print("Found {} faces in image.".format(len(face_locations)))
    face_encodings = face_recognition.face_encodings(output, face_locations)

    # Loop over each face found in the frame to see if it's someone we know.
    for face_encoding in face_encodings:
        # See if the face is a match for the known face(s)
        matchp1 = face_recognition.compare_faces([p1_face_encoding], face_encoding)
        
        if matchp1[0]:
            nameobama = "p1"
			print("I see for first time someone named {}!".format(namep1))
			y1=y1+1
            if y1==2 :
            main_p1()
            z1=1;
        print("I see someone named {}!".format(namep1))
		
        matchp2 = face_recognition.compare_faces([p2_face_encoding], face_encoding)
       
        if matchp2[0]:
            namep2 = "p2"
			print("I see for first time someone named {}!".format(namep2))
			y2=y2+1
            if y2==2 :
            main_p2()
            z2=2;
        print("I see someone named {}!".format(namep2))
		
		matchp3 = face_recognition.compare_faces([p3_face_encoding], face_encoding)
        
        if matchp3[0]:
            nameakshay = "p3"
			print("I see for first time someone named {}!".format(namep3))
			y3=y3+1
            if y3==2 :
            main_p3()
            z3=1;
        print("I see someone named {}!".format(namep3))
		
		matchp4 = face_recognition.compare_faces([p4_face_encoding], face_encoding)
        
        if matchp4[0]:
            namep4 = "p4"
			print("I see for first time someone named {}!".format(namep4))
			y4=y4+1
            if y4==2 :
            main_p4()
            z4=1;
        print("I see someone named {}!".format(namep4))
		
		if matchp5[0]:
            namep5 = "p5"
			print("I see for first time someone named {}!".format(namep5))
			y5=y5+1
            if y5==2 :
            main_p5()
            z5=1;
        print("I see someone named {}!".format(namep5))
		
		
        if  (z1==1 and z2==2 and z3==1 and z4==1 and z5==1) :  
            book.save('Attendance.xls')
			with open("Attendance.xls", "rb") as f:
            dbx = dropbox.Dropbox('Insert Dropbox access token here') 
            dbx.files_upload(f.read(), 'Attendance.xls')
            f.close() 
            print("Finish")
            exit()
